#!/bin/bash

echo "No custom init script provided"